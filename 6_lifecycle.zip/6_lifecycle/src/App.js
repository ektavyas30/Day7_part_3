
import './App.css';
import LifeCycle from './Component/LifeCycle'
function App() {
  return (
    <>
    <h1>God is One...</h1>
    <LifeCycle/>
    </>
  );
}

export default App;
