import './App.css';
//import UserEffectDemo from './Component/useEffect'
import CustomHookDemoComponent_1 from './Component/CustomHookDemoComponent_1';
import CustomHookDemoComponent_2 from './Component/CustomHookDemoComponent_2';

function App() {
  return (
   // <UserEffectDemo/>
    <> 
        <CustomHookDemoComponent_1 />
        <CustomHookDemoComponent_2 />
    </> 
  );
}

export default App;
